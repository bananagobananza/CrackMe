name = "Form1"
key1 = f"{name[-1]}118{name[-3]}4"
key2 = f"132{name[3]}5{name[3]}"
key3 = f"12254{name[2]}"

print(f"Key: {key3} - {key1} - {key2}")